package com.project.MentorOnDemand.MentorDetails;


import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.LinkedHashSet;


public interface MentorDetailsRepository extends CrudRepository<MentorDetails, String> {

	@Query(value = "SELECT userName from MentorDetails")
    ArrayList<String> findAllUserNames();


    @Query(value="select userName from MentorDetails")
    ArrayList<String> findMentorNames();

    @Transactional
    @Modifying
    @Query(value="Select user_name from traineedatabase.trainees_details",nativeQuery = true)
    ArrayList<String> findTraineeNames();

    @Transactional
    @Query(value="SELECT calendar_num from calendardatabase.mentor_calendar where start_date=?1 and end_date=?2",nativeQuery = true)
    int findCalendarNum(java.sql.Date sDate, java.sql.Date eDate);

    @Query(value = "SELECT user_name,password from mentor_details",nativeQuery = true)
    ArrayList<Object[]> findMentors();

    @Transactional
    @Query(value="SELECT calendar_num from mentor_details where user_name=?1",nativeQuery = true)
    int findMentorCalendarNumber(String userName);

    @Query(value="SELECT course_name from admindatabase.admin_details",nativeQuery = true)
    LinkedHashSet<String> findAllCourses();

    @Query(value="select Count(userName) from MentorDetails where courseName=?1")
    int findCount(String cname);

    @Modifying
    @Transactional
    @Query(value="UPDATE admindatabase.admin_details SET num_mentors=?2 WHERE course_name=?1",nativeQuery = true)
    int updateCount(String cname,int count);

    @Modifying
    @Transactional
    @Query(value="INSERT INTO admindatabase.admin_details( course_name,num_mentors) VALUES(:cname,:num)",nativeQuery = true)
    void saveCourses(String cname,int num);
}
