package com.project.MentorOnDemand.MentorDetails;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;


@Service
public class MentorServices {

	@Autowired
	private MentorDetailsRepository mentorDetailsRepository;

//	public List<MentorDetails> getMentorDetails() {
//		List<MentorDetails> mentorsList=new ArrayList<>();
//		mentorDetailsRepository.findAll().forEach(mentorsList::add);
//		return mentorsList;
//	}

	public List<MentorDetails> getMentorsList() {
		// TODO Auto-generated method stub
		List<MentorDetails> mentorsList=new ArrayList<>();
		mentorDetailsRepository.findAll().forEach(mentorsList::add);
		return mentorsList;


	}


	public void addMentor(MentorDetails mentorDetails) {
		// TODO Auto-generated method stub
		Double commission=mentorDetails.getFees()*(0.278);
		 BigDecimal bd = new BigDecimal(commission).setScale(2, RoundingMode.HALF_UP);
	        double comm = bd.doubleValue();
		mentorDetails.setIsBlocked("No");
		mentorDetails.setCommission(comm);
		mentorDetails.setTotalFees(comm+mentorDetails.getFees());
		Boolean isPresent=false;
		ArrayList<String> userNameList= mentorDetailsRepository.findAllUserNames();
		if(userNameList.isEmpty()){
			mentorDetailsRepository.save(mentorDetails);
		}else {
			for (int i = 0; i < userNameList.size(); i++) {
				if (userNameList.contains(mentorDetails.getUserName())) {
					isPresent = true;
					throw new DataIntegrityViolationException("already exists");
					//break;
				} else {
					isPresent = false;
				}
			}
			if (isPresent == false) {
				mentorDetailsRepository.save(mentorDetails);
			}
		}
	}


	public MentorDetails getMentor(String userName) {
		MentorDetails mentorDetails=mentorDetailsRepository.findById(userName).get();
		return mentorDetails;
	}

	public void addCalendar(MentorCalendar mentorCalendar, String userName) {
		MentorDetails mentorDetails=new MentorDetails();
		mentorDetails=mentorDetailsRepository.findById(userName).get();
		List<MentorDetails>mentorDetailsList=new ArrayList<MentorDetails>();
		mentorDetailsList.add(mentorDetails);
		mentorCalendar.setMenDetailsList(mentorDetailsList);
	}

	public void checkForMentor(MentorDetails mentorDetails) throws Exception {
		ArrayList<String> mentorNames=mentorDetailsRepository.findMentorNames();

		if(mentorNames.contains(mentorDetails.getUserName())) {
			throw new Exception("USER ALREADY EXISTS");
		}
	}

	public void checkForTrainee(MentorDetails mentorDetails) throws Exception {
		// TODO Auto-generated method stub
		ArrayList<String> traineeNames=mentorDetailsRepository.findTraineeNames();

		if(traineeNames.contains(mentorDetails.getUserName())) {
			throw new Exception("USER ALREADY EXISTS");
		}
	}

	public List<MentorDetails> getMentorDetails(String courseName, Date sDate, Date eDate) {
		System.out.println("date="+sDate);
		List<MentorDetails> mentorsList=new ArrayList<>();
		mentorDetailsRepository.findAll().forEach(mentorsList::add);

		int calNum=mentorDetailsRepository.findCalendarNum(sDate,eDate);

		System.out.println("calNum="+calNum);
		List<MentorDetails> searchList=new ArrayList<>();
		for(int i=0;i<mentorsList.size();i++) {
			MentorDetails menDetails=mentorsList.get(i);
			int numberInCal=mentorDetailsRepository.findMentorCalendarNumber(menDetails.getUserName());
			System.out.println("numberInCal="+numberInCal);
			if(menDetails.getCourseName().equalsIgnoreCase(courseName) && numberInCal==calNum)
				searchList.add(menDetails);
		}
		return searchList;

	}

	public void addCourse(MentorDetails mentorDetails)  {
		String cname=mentorDetails.getCourseName();

		LinkedHashSet<String> coursesAll=mentorDetailsRepository.findAllCourses();
		int count=mentorDetailsRepository.findCount(cname);
		Boolean isPresent=false;
		AdminDetails adminCourses = new AdminDetails();

		if(coursesAll.isEmpty()) {
//			adminCourses.setCourseName(mentorDetails.getCourseName());
//			adminCourses.setNumMentors(count);
			mentorDetailsRepository.saveCourses(mentorDetails.getCourseName(),count);
		}
		else {
			for(String str:coursesAll) {
				if(mentorDetails.getCourseName().equalsIgnoreCase(str)) {
					System.out.println("hello");
					mentorDetailsRepository.updateCount(cname, count);
					isPresent=false;
					break;
				}
				else {
					System.out.println("hiii");
					isPresent=true;
				}
			}
			if(isPresent==true){
//				adminCourses.setCourseName(mentorDetails.getCourseName());
//				adminCourses.setNumMentors(count);
				mentorDetailsRepository.saveCourses(mentorDetails.getCourseName(),count);
			}
		}

	}
}
