package com.project.MentorOnDemand.MentorDetails;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.sql.Date;
import java.util.List;

@RestController
@CrossOrigin(origins="http://localhost:4200")

public class MentorDetailsController {
    @Autowired
    MentorServices mentorServices;

    @RequestMapping("/mentorsList")
    public List<MentorDetails> getMentorsList(){
        return mentorServices.getMentorsList();
    }

    @RequestMapping(value="/getMentor/{userName}")
    public MentorDetails getMentor(@PathVariable(value="userName") String userName){
        MentorDetails mentorDetails=mentorServices.getMentor(userName);
        return mentorDetails;
    }
    @RequestMapping(method = RequestMethod.POST,value="/addMentor")
    public void addMentor(@RequestBody MentorDetails mentorDetails) throws Exception {
        mentorServices.checkForMentor(mentorDetails);
        mentorServices.checkForTrainee(mentorDetails);
        mentorServices.addMentor(mentorDetails);
        mentorServices.addCourse(mentorDetails);
    }

    @RequestMapping("/mentorsList/{courseName}/{sDate}/{eDate}")
    public List<MentorDetails> getMentorDetails(@PathVariable String courseName, @PathVariable Date sDate, @PathVariable Date eDate)  {
        return mentorServices.getMentorDetails(courseName,sDate,eDate);
    }




}
