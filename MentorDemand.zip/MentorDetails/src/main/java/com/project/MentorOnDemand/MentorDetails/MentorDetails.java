package com.project.MentorOnDemand.MentorDetails;



import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table(name="MentorDetails")
public class MentorDetails {

	@Id @Column(unique = true)
	private String userName;	//email
	private String courseName;
	private Double fees;
	private Double commission;
	private String isBlocked;
	private Double totalFees;
	private String password;

	private String firstName;
	private String phoneNumber;
	private Date dateOfBirth;
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Double getTotalFees() {
		return totalFees;
	}
	public void setTotalFees(Double totalFees) {
		this.totalFees = totalFees;
	}
	public String getIsBlocked() {
		return isBlocked;
	}
	public void setIsBlocked(String isBlocked) {
		this.isBlocked = isBlocked;
	}
	public Double getCommission() {
		return commission;
	}
	public void setCommission(Double commission) {
		this.commission = commission;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public Double getFees() {
		return fees;
	}
	public void setFees(Double fees) {
		this.fees = fees;
	}

	
//@ManyToMany(cascade = CascadeType.ALL)
//private Collection<Trainings> trainings;
//
//public Collection<Trainings> getTrainings() {
//	return trainings;
//}
//public void setTrainings(Collection<Trainings> trainings) {
//	this.trainings = trainings;
//}

	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="calendar_num")
	private MentorCalendar mentorCalendar;

	@JsonIgnore
	public MentorCalendar getMentorCalendar() {
		return mentorCalendar;
	}
	public void setMentorCalendar(MentorCalendar mentorCalendar) {
		this.mentorCalendar = mentorCalendar;
	}

	public MentorDetails() {

	}
	
	
}
