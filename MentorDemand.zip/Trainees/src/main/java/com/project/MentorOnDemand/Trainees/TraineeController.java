package com.project.MentorOnDemand.Trainees;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class TraineeController {

    @Autowired
    private TraineesService traineesService;

    @RequestMapping(method= RequestMethod.POST,value="/addTrainee")
    public void addTrainee(@RequestBody TraineesDetails traineesDetails) throws Exception {
        traineesService.checkForMentor(traineesDetails);
        traineesService.checkForTrainee(traineesDetails);
        traineesService.addTrainee(traineesDetails);
    }

    @RequestMapping(method=RequestMethod.GET,value="/getTrainee")
    public List<TraineesDetails> getTraineesList() {

        return traineesService.getTraineesList();
    }
}
