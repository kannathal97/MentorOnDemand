package com.project.MentorOnDemand.Trainees;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@EnableEurekaClient

@SpringBootApplication
public class TraineesApplication {

	public static void main(String[] args) {
		SpringApplication.run(TraineesApplication.class, args);
	}

}
