package com.project.MentorOnDemand.Trainees;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;


public interface TraineeRepository extends CrudRepository<TraineesDetails, String>{

    @Modifying
    @Transactional
    @Query(value="select user_name from mentordetailsdatabase.mentor_details",nativeQuery = true)
    ArrayList<String> findMentorNames();

    @Query(value="Select userName from TraineesDetails")
    ArrayList<String> findTraineeNames();
}
