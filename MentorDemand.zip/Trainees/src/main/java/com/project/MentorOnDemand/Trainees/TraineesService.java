package com.project.MentorOnDemand.Trainees;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
//
//
//@Service
//public class TraineesService {
//
//	@Autowired
//	TraineeRepository traineeRepository;
//	public void addTrainee(TraineesDetails traineesDetails) {
//		// TODO Auto-generated method stub
//		traineesDetails.setFeesStatus("Paid");
//		traineeRepository.save(traineesDetails);
//
//
//
//	}
//
//}

@Service
public class TraineesService {

	@Autowired
	TraineeRepository traineeRepository;
//	@Autowired
//	MentorDetailsRepository mentorDetailsRepository;
	public void addTrainee(TraineesDetails traineesDetails) {
		// TODO Auto-generated method stub
		traineesDetails.setFeesStatus("Paid");
		traineeRepository.save(traineesDetails);

	}



	public void checkForMentor(TraineesDetails traineesDetails) throws Exception {
		// TODO Auto-generated method stub
		ArrayList<String> mentorNames=traineeRepository.findMentorNames();

		if(mentorNames.contains(traineesDetails.getUserName())) {
			throw new Exception("USER ALREADY EXISTS");
		}
	}



	public void checkForTrainee(TraineesDetails traineesDetails) throws Exception {
		// TODO Auto-generated method stub
		ArrayList<String> traineeNames=traineeRepository.findTraineeNames();

		if(traineeNames.contains(traineesDetails.getUserName())) {
			throw new Exception("USER ALREADY EXISTS");
		}
	}



	public List<TraineesDetails> getTraineesList() {
		// TODO Auto-generated method stub
		List<TraineesDetails> traineesList=new ArrayList<TraineesDetails>();
		traineeRepository.findAll().forEach(traineesList::add);
		return traineesList;
	}
}
