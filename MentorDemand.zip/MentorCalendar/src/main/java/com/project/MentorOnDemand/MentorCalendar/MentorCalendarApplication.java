package com.project.MentorOnDemand.MentorCalendar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@EnableEurekaClient

@SpringBootApplication
public class MentorCalendarApplication {

	public static void main(String[] args) {
		SpringApplication.run(MentorCalendarApplication.class, args);
	}

}
