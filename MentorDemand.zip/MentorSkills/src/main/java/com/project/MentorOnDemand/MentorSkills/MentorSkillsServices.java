package com.project.MentorOnDemand.MentorSkills;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service
public class MentorSkillsServices {

	@Autowired
	MentorSkillsRepository mentorSkillsRepository;
	

	
	public void addSkills(MentorSkills mentorSkills,String userName) {

		//MentorDetails mentorDetails=new MentorDetails();
		System.out.println("details="+userName);
		//MentorDetails mentorDetails=mentorSkillsRepository.findMentorDetails(userName);
		//mentorSkills.setMentorDetails(mentorDetails);



		Boolean isThere=false;



		String skillName=mentorSkills.getSkillName();

		ArrayList<String> skillsNameList=mentorSkillsRepository.findSkillNames();

		if(skillsNameList.isEmpty()) {
			mentorSkills.setSkillId(1);
			mentorSkillsRepository.save(mentorSkills);
		}else {
			for(int i=0;i<skillsNameList.size();i++) {
				if(skillsNameList.get(i).equalsIgnoreCase(skillName)) {
					mentorSkills.setSkillId(i+1);
					isThere=true;
					break;
				}else {
					isThere=false;
				}
			}
			if(isThere==false) {
				mentorSkills.setSkillId(skillsNameList.size()+1);
				mentorSkillsRepository.save(mentorSkills);
			}
		}

		//mentorSkillsRepository.save(mentorSkills);
		int skillId=mentorSkills.getSkillId();
		System.out.println("id="+skillId);
		mentorSkillsRepository.insertSkills(userName,skillId);



		
		

	}

	public List<String> getMentorSkills(String userName) {
		// TODO Auto-generated method stub
		List<Integer> skillNumbers=new ArrayList<Integer>();
		skillNumbers=mentorSkillsRepository.getSkillNumbers(userName);
		MentorSkills mentorSkills=new MentorSkills();
		List<String> skillNames=new ArrayList<String>();
		for(int i=0;i<skillNumbers.size();i++) {
			int skillNum=skillNumbers.get(i);
			mentorSkills=mentorSkillsRepository.findById(skillNum).get();
			String skillName=mentorSkills.getSkillName();
			skillNames.add(skillName);
		}
		return skillNames;
	}



}
