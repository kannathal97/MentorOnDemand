package com.project.MentorOnDemand.MentorSkills;

import javax.persistence.*;
import java.util.Collection;

@Entity
@Table(name="mentorSkills")
public class MentorSkills {

	@Id
	//@GeneratedValue(strategy = GenerationType.TABLE)
	private int skillId;
	private String skillName;
	public int getSkillId() {
		return skillId;
	}
	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}
	public String getSkillName() {
		return skillName;
	}
	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}


	@ManyToMany(mappedBy = "mentorSkills")
	private Collection<MentorDetails> mentorDetails;
	public Collection<MentorDetails> getMentorDetails() {
		return mentorDetails;
	}
	public void setMentorDetails(Collection<MentorDetails> mentorDetails) {
		this.mentorDetails = mentorDetails;
	}
	
	
	
	
}
