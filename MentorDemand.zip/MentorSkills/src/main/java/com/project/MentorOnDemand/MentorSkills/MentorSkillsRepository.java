package com.project.MentorOnDemand.MentorSkills;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;


public interface MentorSkillsRepository extends CrudRepository<MentorSkills, Integer> {

    @Modifying
    @Transactional
    @Query(value = "UPDATE mentor_skills SET mentor_name=?1 WHERE skill_id=?2",nativeQuery = true)
    void updateMentorName(String userName,int skillId);

    @Query(value="SELECT skillName from MentorSkills")
    ArrayList<String> findSkillNames();

    @Query(value="SELECT  mentor_skills_skill_id from  mentor_details_mentor_skills where mentor_details_user_name=?1",nativeQuery = true)
    List<Integer> getSkillNumbers(String userName);

    @Modifying
    @Transactional
    @Query(value="INSERT INTO mentor_details_mentor_skills( mentor_details_user_name,mentor_skills_skill_id) VALUES(:userName,:skillId)",nativeQuery = true)
    void insertSkills(String userName,Integer skillId);


}
