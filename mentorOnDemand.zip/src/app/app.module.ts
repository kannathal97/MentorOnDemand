import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SerachBarComponent } from './serach-bar/serach-bar.component';
import { SigninComponent } from './signin/signin.component';
import { ReactiveFormsModule} from '@angular/forms';
import { SignupComponent } from './signup/signup.component';


import {FormsModule} from '@angular/forms';
import { MatDatepickerModule, MatInputModule, MatNativeDateModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import { SearchresultsComponent } from './searchresults/searchresults.component';
import { HttpClientModule } from '@angular/common/http';
import {RouterModule} from '@angular/router';


import { HomepageComponent } from './homepage/homepage.component';
import { MentorprofileComponent } from './mentorprofile/mentorprofile.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { PaymentComponent } from './payment/payment.component';

import { FooterComponent } from './footer/footer.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { MainLayoutComponent } from './layouts/main-layout/main-layout.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    
    SerachBarComponent,
    SigninComponent,
    SignupComponent,
  
    SearchresultsComponent,
  
    
  
    HomepageComponent,
  
   
  
    MentorprofileComponent,
  
    
  
    UserProfileComponent,
  
    
  
    PaymentComponent,
  
   
  
    FooterComponent,
  
    AdminLoginComponent,
  
  
  
    AdminpageComponent,
  
   
    MainLayoutComponent,
  

   
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    MatDatepickerModule,
    MatInputModule,
    MatNativeDateModule,
    BrowserAnimationsModule,
    MatAutocompleteModule,
    HttpClientModule,
    RouterModule,
    MatSlideToggleModule,
        //routing
  ],
  
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
