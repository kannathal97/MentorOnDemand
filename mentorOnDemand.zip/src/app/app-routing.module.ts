import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SerachBarComponent } from './serach-bar';
import { SigninComponent } from './signin';
import { SignupComponent } from './signup/signup.component';
import {SearchresultsComponent} from './searchresults/searchresults.component';
import { PaymentComponent } from './payment/payment.component';

import { HomepageComponent } from './homepage/homepage.component';
import { MentorprofileComponent } from './mentorprofile/mentorprofile.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { MainLayoutComponent } from './layouts/main-layout/main-layout.component';
const routes: Routes = [
  {
    path: '',
    component: MainLayoutComponent,
    children: [
      {
        path: '',
        component: SerachBarComponent
      },
     
    ]
  },
  {
    path: '',
    component: MainLayoutComponent,
    children: [
      {
        path: 'signin',
        component: SigninComponent
      }
    ]
  },
  {
    path: '',
    component: MainLayoutComponent,
    children: [
      {
        path: 'signup',
        component: SignupComponent
      }
    ]
  },
  {
    path: '',
    component: MainLayoutComponent,
    children: [
      {
        path: 'techs/:techId',
        component: SearchresultsComponent
      }
    ]
  },
  {
    path: '',
    component:MainLayoutComponent ,
    children: [
      {
        path: 'home',
        component: HomepageComponent
      }
    ]
  }, 
  {
    path: '',
    component:MainLayoutComponent ,
    children: [
      {
        path: 'mentorProfile',
        component: MentorprofileComponent
      }
    ]
  },
  {
    path: '',
    component:MainLayoutComponent ,
    children: [
      {
        path: 'userProfile',
        component: UserProfileComponent
      }
    ]
  },
  {
    path: '',
    component:MainLayoutComponent ,
    children: [
      {
        path: 'pay',
        component: PaymentComponent
      }
    ]
  },
  {
    path: '',
    component:MainLayoutComponent ,
    children: [
      {
        path: 'admin',
        component: AdminLoginComponent
      }
    ]
  },
  {
    path: '',
    component:MainLayoutComponent ,
    children: [
      {
        path: 'adminPage',
        component: AdminpageComponent
      }
    ]
  },
  
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

