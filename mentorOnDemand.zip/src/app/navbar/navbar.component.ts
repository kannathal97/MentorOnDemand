import { Component, OnInit } from '@angular/core';
import {Router,ActivatedRoute} from '@angular/router';
import { Location } from "@angular/common";
import { ValidationService, Credentials } from '../validation.service';
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
  public href: string = "";
  userDetails;
 // rout:String;
  constructor(private router: Router,private arouter:ActivatedRoute,location: Location,private validationService:ValidationService) {
 
}



  firstLetter;
 // uname:String;
proposal:String;
isTechs:Boolean;
isSignIn:Boolean;
isSignUp:Boolean;
isHome:Boolean;
isAdmin:Boolean;
isAdminPage:Boolean;
isMentor:Boolean;
  ngOnInit() {
    
    this.href = this.router.url;
  console.log("root="+this.router.url);
 //console.log("root="+this.rout);
  if(this.href.startsWith("/techs/" )){
    this.isTechs=true;
  }else if(this.href=="/signin"){
    this.isSignIn=true;
  }else if(this.href=="/signup"){
    this.isSignUp=true;
  }else if(this.href=="/home"){
    this.proposal="Your Proposal is accepted";
    this.isHome=true;
  }else if(this.href=="/"){
    this.isTechs=true;
  }else if(this.href=="/admin"){
    this.isAdmin=true;
  }else if(this.href=="/adminPage"){
    this.isAdminPage=true;
  }else if(this.href=="/mentorProfile"){
    this.proposal="New Proposal";
    this.isMentor=true;
    this.isHome=true;
  }else{
    this.isHome=true;
    this.proposal="Your Proposal is accepted";
  }
//   this.model.username="";
//   this.userDetails=this.validationService.getUserDetails().subscribe((data:Credentials)=>
// {
//   this.model.username=data[0].name;
//   this.uname=this.model.username;
//   this.firstLetter=this.uname.charAt(0).toUpperCase();
// });
this.firstLetter=this.validationService.firstLetter;
  }

 

}
