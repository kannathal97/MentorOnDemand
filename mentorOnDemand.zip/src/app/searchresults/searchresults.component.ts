import { Component, OnInit ,Input} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import{ValidationService, Mentor} from '../validation.service';
import { techs } from '../tech';
@Component({
  selector: 'app-searchresults',
  templateUrl: './searchresults.component.html',
  styleUrls: ['./searchresults.component.scss'],
  
})
export class SearchresultsComponent implements OnInit {

  constructor( private route: ActivatedRoute,private rout: Router,private validationService:ValidationService) { }
tech=[];
onClick(){
  document.getElementById("clicks").click();
  this.rout.navigate(['/pay']);
}

mentorDetails;
i;
fees;
gst;
total;
nameOfCourse;
startDateOfCourse;
endDateOfCourse;
// searchResultsLength;
// blank:boolean;
  ngOnInit() {
  
  this.route.paramMap.subscribe(params=>{
    console.log(params.get('techId')+"====");
    this.nameOfCourse=params.get('techId');
    this.startDateOfCourse=this.validationService.sDate;
    this.endDateOfCourse=this.validationService.eDate;
   this.mentorDetails=this.validationService.getSearchResults(this.nameOfCourse,this.startDateOfCourse,this.endDateOfCourse).subscribe((data:Mentor)=>{
    //  console.log(Object.keys(data).length);
    //  this.searchResultsLength=Object.keys(data).length;
     
     var index=0;
     for(this.i=0;this.i<Object.keys(data).length;this.i++){
       console.log("=>"+data[this.i].fees);
        this.gst=25;
       this.tech[index]=data[this.i];
       index++;
     }
   });

  });

  

  } 
}



