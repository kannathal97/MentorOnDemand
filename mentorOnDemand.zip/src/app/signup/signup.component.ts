import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';

import { Router } from '@angular/router';
import { User, ValidationService,Mentor, Calendar, Skills } from '../validation.service';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {

  signUpForm: FormGroup;
  mentorSignUpForm:FormGroup;
  checkings: Boolean;
  submitted: Boolean;
  submitting:Boolean;
  constructor(private formBuilder: FormBuilder, private route: Router, private validationService:ValidationService) {
    this.submitted = false;
  }

  ngOnInit() {     
    this.initSignUpForm();
    this.initMentorSignUpForm();
  }

user:User=new User();
mentor:Mentor=new Mentor();
calendar:Calendar=new Calendar();
skills:Skills=new Skills();
  onSubmit() {
    this.user.userName=this.signUpForm.get('Email').value;
    this.user.password=this.signUpForm.get('Password').value;
    this.user.firstName=this.signUpForm.get('firstName').value;
    this.user.phoneNumber=this.signUpForm.get('phoneNumber').value;
    this.user.dateOfBirth=this.signUpForm.get('DateOfBirth').value;
    this.submitted = true;
    this.saveUser();
    if (this.signUpForm.valid)
      this.route.navigate(['/signin']);   
  }

  saveUser(){
    this.validationService.postUserDetails(this.user).subscribe(data => console.log(data), error => console.log(error));
  }

  onSubmitted(){
    this.mentor.userName=this.signUpForm.get('Email').value;
    this.mentor.password=this.signUpForm.get('Password').value;
    this.mentor.firstName=this.signUpForm.get('firstName').value;
    this.mentor.phoneNumber=this.signUpForm.get('phoneNumber').value;
    this.mentor.dateOfBirth=this.signUpForm.get('DateOfBirth').value;
    this.mentor.courseName=this.mentorSignUpForm.get('courseName').value;
    this.mentor.fees=this.mentorSignUpForm.get('fees').value;
   this.calendar.startDate=this.mentorSignUpForm.get('timings').value;
   this.calendar.endDate=this.mentorSignUpForm.get('enddate').value;
    this.submitting=true;
    this.submitted=true;
    this.saveMentor();
    this.saveCalendar();
    this.saveSkill();
    if(this.mentorSignUpForm.valid && this.signUpForm.valid)
      this.route.navigate(['/signin']);
  }

  saveMentor(){
    this.validationService.postMentorDetails(this.mentor).subscribe(data=>console.log(data),error=>console.log(error));
  }

  saveCalendar(){
    this.validationService.postCalendar(this.calendar,this.mentor.userName).subscribe();
  }
i;
  saveSkill(){
    for(this.i=0;this.i<this.interests.length;this.i++){
      console.log(this.interests[this.i]);
      this.skills.skillName=this.interests[this.i];
      this.validationService.postSkills(this.skills,this.mentor.userName).subscribe(error=>console.log(error));
      
    }
  }

  get f() { return this.signUpForm.controls; }

  private initSignUpForm() {


    this.signUpForm = this.formBuilder.group({
      Email: new FormControl('', [Validators.required, Validators.email]),
      firstName: ['', Validators.required],
      Password: new FormControl(null, [Validators.required, Validators.minLength(6)]),
      phoneNumber:new FormControl(''),
      DateOfBirth:new FormControl(''),
      
    }
    );

  }

  private initMentorSignUpForm(){

    this.mentorSignUpForm = this.formBuilder.group({
        courseName:['',Validators.required],
        fees: ['', Validators.required],
        enddate :['',Validators.required],
    timings:['',Validators.required],
    experience:['',Validators.required],
    skills:['']
    }
    );

  }

  get g(){return this.mentorSignUpForm.controls;}

  interests = [];


  onCheckboxChagen(event, value) {
console.log(value);
if (event.target.checked) {
  console.log("pushed="+value);
  this.interests.push(value);
} 

if (!event.target.checked) {

  let index = this.interests.indexOf(value);
  if (index > -1) {
    this.interests.splice(index, 1);
  }
}

console.log("Interests array => " + JSON.stringify(this.interests, null, 2));
}


}




