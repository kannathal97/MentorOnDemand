import { Component } from '@angular/core';

//export type EditorType = 'name'|'profile';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  template:'<router-outlet></router-outlet>',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'mentorApp';  
  constructor(

  ){}
  /*editor: EditorType = 'name';

  get showSignIn() {
    return this.editor === 'name';
  }

  get showProfileEditor() {
    return this.editor === 'profile';
  }

  toggleEditor(type: EditorType) {
    this.editor = type;
  }*/
}
