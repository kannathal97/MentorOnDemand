import { Component, OnInit } from '@angular/core';
import { ValidationService, Credentials, User } from '../validation.service';
@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.scss'],
 
})
export class HomepageComponent implements OnInit {
userDetails;

  constructor(private validationService:ValidationService) { }

  model:any={
    username:String,}

firstLetter;
uname:String;
  ngOnInit() { 
    this.model.username="";
    this.userDetails=this.validationService.getUserDetails().subscribe((data:User)=>
  {
    this.model.username=data[0].userName;
    this.uname=this.model.username;
    this.firstLetter=this.uname.charAt(0).toUpperCase();
  });
  }
  

}
