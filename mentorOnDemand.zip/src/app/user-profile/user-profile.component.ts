import { Component, OnInit } from '@angular/core';
import { ValidationService } from '../validation.service';
@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.scss']
})
export class UserProfileComponent implements OnInit {

  email;
  personalName;
  phone;
  dob;
  skills=[];
  badge=[];
  userDetails;
firstLetter;
  constructor(private validationService:ValidationService) { }

  ngOnInit() {
    this.email=this.validationService.email;
    this.personalName=this.validationService.personalName;
    //console.log("=>"+this.validationService.badge[0]);
     this.phone=this.validationService.phone;
     this.dob=this.validationService.dob;
    // this.skills=this.validationService.skills;
    // this.badge=this.validationService.badge;

    this.firstLetter=this.validationService.firstLetter;

    
  
  }

}
