import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormControl,FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.scss']
})
export class AdminLoginComponent implements OnInit {

useremail=new FormControl();
userpassword=new FormControl();
submitted=false;
adminform;

correctemail="test@gmail.com";
correctpass="test";

  constructor(private router: Router,private formBuilder:FormBuilder) { }

  ngOnInit() {
    this.adminform=this.formBuilder.group({
      useremail:['',[Validators.required]],
      userpassword:['',[Validators.required]]
    });
  }
  get f() {return this.adminform.controls;}
  onadminlogin(data){
    this.useremail=data.useremail;
    this.userpassword=data.userpassword;
    this.submitted=true;
   // console.log("=>"+data.useremail);
    if(data.useremail==this.correctemail && data.userpassword==this.correctpass && this.adminform.valid)
      this.router.navigate(['/adminPage'])
  }

  

}
