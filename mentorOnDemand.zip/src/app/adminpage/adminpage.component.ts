import { Component, OnInit } from '@angular/core';
import { ValidationService, Credentials, Mentor ,User} from '../validation.service';
@Component({
  selector: 'app-adminpage',
  templateUrl: './adminpage.component.html',
  styleUrls: ['./adminpage.component.scss']
})
export class AdminpageComponent implements OnInit {

  constructor(private validationService:ValidationService,) { }
mentorsDetails;
userDetails;
techDetails;
detailtech=[];
detailmentor=[];
detailuser=[];

i;
  ngOnInit() {
    this.mentorsDetails=this.validationService.getMentorDetails().subscribe((data:Mentor)=>
    {
      for(this.i=0;this.i<Object.keys(data).length;this.i++){
        this.detailmentor[this.i]=data[this.i];
        console.log(this.detailmentor[this.i]);
      }
  });

  this.userDetails=this.validationService.getUserDetails().subscribe((userdata:User)=>
  {
    for(this.i=0;this.i<Object.keys(userdata).length;this.i++){
      this.detailuser[this.i]=userdata[this.i];
      //console.log(this.detailmentor[this.i]);
    }
  }
);

this.techDetails=this.validationService.getTechDetails().subscribe((techdata:Credentials)=>
{
  for(this.i=0;this.i<Object.keys(techdata).length;this.i++){
    this.detailtech[this.i]=techdata[this.i];
    //console.log(this.detailmentor[this.i]);
  }
});

}
}
