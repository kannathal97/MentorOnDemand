import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidationService, Credentials, Mentor, User, Skills } from '../validation.service';
@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss']
})
export class SigninComponent implements OnInit {

  userSignInForm: FormGroup;
  mentorSignInForm: FormGroup;
    submitted:Boolean;
    submitting:Boolean;
    constructor(private formBuilder:FormBuilder,private validationService:ValidationService,private route:Router,) { 
        this.submitted=false;
        this.submitting=false;
       }
       userDetails;
       mentorDetails;
       mentorSkills;
       model:any={
         username:String,
         password:String,
         errorMessage:String,
         validStatus:Boolean,
         mentorname:String,
         mentorpassword:String,
       }

    ngOnInit() {
      this.initMentorSignInForm() ;
      this.initUserSignInForm();
     this.model.username="";
     this.model.password="";
     this.model.mentorname="";
     this.model.mentorpassword="";
     this.model.errorUserMessage="";
     this.model.errorMentorMessage="";
     this.model.invalidUserStatus=false;
     this.model.invalidMentorStatus=false;
    }  
    onSubmit(){
      this.submitted=true;
      this.mentorDetails=this.validationService.getMentorDetails().subscribe((data:Mentor)=>
     {
      for(this.i=0;this.i<Object.keys(data).length;this.i++){
        if(data[this.i].userName==this.model.mentorname && data[this.i].password==this.model.mentorpassword){
         
          this.model.mentorname=data[this.i].userName;
        // this.uname=this.model.username;
        this.validationService.firstLetter=this.model.mentorname.charAt(0).toUpperCase();
        this.validationService.email=data[this.i].userName;
    this.validationService.personalName=data[this.i].firstName;
   this.validationService.phone=data[this.i].phoneNumber;
   this.validationService.dob=data[this.i].dateOfBirth;
   this.addMentorSkills();
   // this.validationService.skills=data[this.i].skills;
    //this.validationService.badge=data[this.i].badge;
    this.flag=true;
          break;
        }
        else{
         this.flag=false;
        }
       }
 
       if(this.flag==true)
         this.route.navigate(['/mentorProfile']);
       else{
          this.model.mentorname="";
         this.model.mentorpassword="";
         this.model.errorMentorMessage="UserName Or PassWord is incorrect";
         this.model.invalidMentorStatus=true;
       }
     });
    }
   
    addMentorSkills(){
      this.mentorSkills=this.validationService.getMentorSkills(this.model.mentorname).subscribe((data:Skills)=>
     {
       //var index=0;
        for(this.i=0;this.i<Object.keys(data).length;this.i++){
          console.log(data[this.i]);
          this.validationService.skills[this.i]=data[this.i];
          //index++;
          console.log(this.validationService.skills.length)
        }
        this.validationService.skills=[];
     });
    }
   
    i;
   flag:Boolean;
    onSubmiting(){
      this.submitting=true;
      
     this.userDetails=this.validationService.getUserDetails().subscribe((data:User)=>
     {
       //console.log(Object.keys(data).length);
       for(this.i=0;this.i<Object.keys(data).length;this.i++){
       if(data[this.i].userName==this.model.username && data[this.i].password==this.model.password){
         this.flag=true;
         this.model.username=data[this.i].userName;
        // this.uname=this.model.username;
        this.validationService.firstLetter=this.model.username.charAt(0).toUpperCase();
        this.validationService.email=data[this.i].userName;
        this.validationService.personalName=data[this.i].firstName;
       this.validationService.phone=data[this.i].phoneNumber;
       this.validationService.dob=data[this.i].dateOfBirth;
       // this.validationService.skills=data[this.i].skills;
       // this.validationService.badge=data[this.i].badge;
         break;
       }
       else{
        this.flag=false;
       }
      }

      if(this.flag==true)
        this.route.navigate(['/home']);
      else{
         this.model.username="";
        this.model.password="";
        this.model.errorUserMessage="UserName Or PassWord is incorrect";
        this.model.invalidUserStatus=true;
      }


     });
    }

    get g() {return this.userSignInForm.controls;}
    
    private initUserSignInForm(){
      this.userSignInForm = this.formBuilder.group({
          Email : new FormControl('',[Validators.required, Validators.email]),
          Password :new FormControl(null,[Validators.required,Validators.minLength(6)])
      }
      );
    }
    get f() {return this.mentorSignInForm.controls;}
    private initMentorSignInForm(){
      this.mentorSignInForm = this.formBuilder.group({
          Email : new FormControl('',[Validators.required, Validators.email]),
          Password :new FormControl(null,[Validators.required,Validators.minLength(6)])
      }
      );
    }

 
}







