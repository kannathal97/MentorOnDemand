import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable,throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class ValidationService {

  constructor(private http:HttpClient,private router: Router) { }
  
  private baseUrl="http://localhost:8761/"

  getUserDetails(){
    return this.http.get<User>(`${this.baseUrl}`+'trainee/getTrainee');
  }
  getMentorDetails(){
    //return this.http.get('/assets/mentorCredentials.json');
    return this.http.get<Mentor>(`${this.baseUrl}`+'mentor/mentorsList');
  }
  getTechDetails(){
    return this.http.get('/assets/technologies.json');
  }
  postUserDetails(user:object):Observable<object>{
    return this.http.post(`${this.baseUrl}`+'trainee/addTrainee',user).pipe(retry(1),catchError(this.handleError));
    //console.log(this.errorMessage+"=");
  }

  postMentorDetails(mentor:object):Observable<object>{
    return this.http.post(`${this.baseUrl}`+'mentor/addMentor',mentor).pipe(retry(1),catchError(this.handleError));
  }

  getSearchResults(cName,sDate:Date,eDate:Date):Observable<Mentor>{
    return this.http.get<Mentor>(`${this.baseUrl}`+'mentor/mentorsList/'+`${cName}`+'/'+`${sDate}`+'/'+`${eDate}`).pipe(retry(1),catchError(this.handlingError));
  }
  postCalendar(calendar:object,uname):Observable<object>{
    return this.http.post<Calendar>(`${this.baseUrl}`+'mentorCalendar/addMentor/addCalendar/'+`${uname}`,calendar);
  }
  postSkills(skill:object,uname):Observable<object>{
    console.log(uname+"=uname");
    console.log("skillName="+skill);
    return this.http.post<Skills>(`${this.baseUrl}`+'mentorSkills/addSkill/'+`${uname}`,skill);
  }
  getMentorSkills(uname){
    return this.http.get(`${this.baseUrl}`+'mentorSkills/getMentorSkills/'+`${uname}`);
  }
 firstLetter;
 email;
 personalName;
 phone;
 dob;
 skills=[];
 badge=[];
 errorMessage='';
sDate;
eDate;

handlingError(error){
  if (error.error instanceof ErrorEvent) {
    // client-side error
    this.errorMessage = `Error: ${error.error.message}`;
  
  } else {
    this.errorMessage='Sorry Trainers are not available';
  }
  window.alert(this.errorMessage);
  return throwError(this.errorMessage);
}

 handleError(error) {
//  let errorMessage = '';
  if (error.error instanceof ErrorEvent) {
    // client-side error
    this.errorMessage = `Error: ${error.error.message}`;
  
  } else {
    this.errorMessage='user already exists \n Please try SigningIn';
  }
  window.alert(this.errorMessage);
  return throwError(this.errorMessage);
}
}

export interface Credentials{
  name:String;
  passw:String;
  ind:String;
  domain:String;
  personalName:String;
  rank:String;
  fees:String;
  
}

export class User{
  firstName:String;
  userName:String;
  password:String;
  phoneNumber:String;
  dateOfBirth:Date;
}

export class Mentor{
  userName:String;
  password:String;
  courseName:String;
  fees:Number;
  totalFees:Number;
  commision:Number;
  isBlocked:String;
  phoneNumber:String;
  dateOfBirth:Date;
  firstName:String;
  isSkill:Boolean;
}

export class Calendar{
  startDate:Date;
  endDate:Date;
}

export class Skills{
  skillName:String;
}
