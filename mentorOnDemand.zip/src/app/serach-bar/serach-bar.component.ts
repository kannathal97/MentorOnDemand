import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {FormControl} from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import { ValidationService } from '../validation.service';

export type EditorType = 'search';

@Component({
  selector: 'app-serach-bar',
  templateUrl: './serach-bar.component.html',
  styleUrls: ['./serach-bar.component.scss']
})
export class SerachBarComponent implements OnInit {

  myControl = new FormControl();
  options: string[] = ['java','angular','bootstrap'];
 dates=new FormControl();
  filteredOptions: Observable<string[]>;
submitted=false;
  constructor( private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private validationService:ValidationService,
   ) { 
   
  }
 searchform:FormGroup;
  ngOnInit() {
    this.filteredOptions = this.myControl.valueChanges
      .pipe(
        startWith(''),
        map(value => this._filter(value))
      );
    
     this.searchform=this.formBuilder.group({
       myControl:['',[Validators.required]],
       dates:['',[Validators.required]],
       enddate:['',Validators.required]
     });
    
     //this.searchform
  }

 

  onClickSearch(data) {
    this.myControl = data.myControl;
    this.dates=data.dates;
     this.validationService.sDate=this.searchform.get('dates').value;
     this.validationService.eDate=this.searchform.get('enddate').value;
     console.log(this.validationService.sDate+"===dt");
    this.submitted=true; 
   // this.searchService.searchTechnology(this.myControl,this.router);
   if(this.searchform.valid ){
     this.router.navigate(['/techs',this.myControl])
   }
  }
  get f() {return this.searchform.controls;}
  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter(option => option.toLowerCase().includes(filterValue));
  }

   
 editor: EditorType;
  
  get showSearchBox() {
    return this.editor === 'search';
  }

  toggleEditor(type: EditorType) {
    this.editor = type;
  }

 
    
  

}
