import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { ValidationService, Credentials } from '../validation.service';
@Component({
  selector: 'app-mentorprofile',
  templateUrl: './mentorprofile.component.html',
  styleUrls: ['./mentorprofile.component.scss']
})
export class MentorprofileComponent implements OnInit {

  email;
  personalName;
  phone;
  dob;
  skills=[];
  badge=[];
  
firstLetter;
  constructor(private formBuilder:FormBuilder,private validationService:ValidationService) { }

  ngOnInit() {
    this.email=this.validationService.email;
    this.personalName=this.validationService.personalName;
    console.log("=>"+this.validationService.badge[0]);
    this.phone=this.validationService.phone;
    this.dob=this.validationService.dob;
    console.log("skill=>"+this.validationService.skills);
    this.skills=this.validationService.skills;
    //this.validationService.skills=[];
    //this.badge=this.validationService.badge;
    this.firstLetter=this.validationService.firstLetter;
  
  }
 



  
}


